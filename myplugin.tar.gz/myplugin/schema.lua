return {

  no_consumer = true,

  fields = {

    say_hello = { type = "boolean", default = true }

  }

}

